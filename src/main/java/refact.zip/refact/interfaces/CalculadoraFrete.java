package refact.interfaces;

public interface CalculadoraFrete {
    double calcular(double peso);
}
