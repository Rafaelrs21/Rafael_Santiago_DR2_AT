package refact.enums;

public enum TipoFrete {
    EXP,
    PAD,
    ECO
}
